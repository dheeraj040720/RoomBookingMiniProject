/*
package Model;

public class Room {

    private int roomId;
    private String roomType;

    private double priceFor24Hours;
    private boolean isAvaliable;

    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    public Room(int roomId, String roomType, double priceFor24Hours) {
        this.roomId = roomId;
        this.roomType = roomType;
        this.priceFor24Hours = priceFor24Hours;
    }


    public Room()
    {

    }

    @Override
    public String toString() {
        return "Room{" +
                "roomId=" + roomId +
                ", roomType='" + roomType + '\'' +
                ", priceFor24Hours=" + priceFor24Hours +
                ", isAvaliable=" + isAvaliable +
                '}';
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public double getPriceFor24Hours() {
        return priceFor24Hours;
    }

    public void setPriceFor24Hours(double priceFor24Hours) {
        this.priceFor24Hours = priceFor24Hours;
    }

    public boolean isAvaliable() {
        return isAvaliable;
    }

    public void setAvaliable(boolean avaliable) {
        isAvaliable = avaliable;
    }
}
*/
